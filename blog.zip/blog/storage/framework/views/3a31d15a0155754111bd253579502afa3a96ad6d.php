<!doctype html>

<?php $__env->startSection('content'); ?>
<html lang="en">
<head>
    <title>Title</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
          integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>
<body>

<div class="container">
    <div class="row">
        <div class="col-md-8 offset-2">
            <h1>Sukurti nauja irasa</h1>
            <hr>
            <form action="<?php echo e(route('posts.store')); ?>" method="post">
                <div class="form-group">
                    <label for="Title">Iveskite varda</label>
                    <input type="text" class="form-control" name="title">
                </div>

                <div class="form-group">
                    <label for="Body">Iveskite automobilio marke</label>
                    <textarea name="body" rows="1" class="form-control"></textarea>
                </div>

                <div class="form-group">
                    <label for="Model">Iveskite automobilio modeli</label>
                    <textarea name="model" rows="1" class="form-control"></textarea>
                </div>

                <div class="form-group">
                    <label for="Date">Iveskite automobilio pagaminimo data</label>
                    <textarea name="date" rows="1" class="form-control"></textarea>
                </div>

                <div class="form-group">
                    <label for="Km">Iveskite automobilio rida</label>
                    <textarea name="km" rows="1" class="form-control"></textarea>
                </div>

                <div class="form-group">
                    <label for="Fuel">Pasirinkite automobilio naudojama kura</label>
                    <select name="fuel" rows="1" class="form-control">
                        <option>Dyzelis</option>
                        <option>Benzinas</option>
                        <option>Dujos</option>
                        <option>Elektra</option>
                        <option>Hibridas</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="Wheel">Pasirinkite automobilio vairo padeti</label>
                    <select name="wheel" rows="1" class="form-control">
                        <option>Kairėje</option>
                        <option>Dešinėje</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="Transmission">Pasirinkite pavarų dežės tipą</label>
                    <select name="transmission" rows="1" class="form-control">
                        <option>Automatine</option>
                        <option>Mechanine</option>
                    </select>
                </div>

                <button type="submit" class="btn btn-primary">Pateikti</button>
                <?php echo csrf_field(); ?>
            </form>
        </div>
    </div>

</div>






<!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
        integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo"
        crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"
        integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1"
        crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"
        integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM"
        crossorigin="anonymous"></script>
</body>
</html>

<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blog\resources\views/posts/create.blade.php ENDPATH**/ ?>