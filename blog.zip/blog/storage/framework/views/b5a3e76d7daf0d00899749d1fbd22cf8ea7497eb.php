<h1>labas</h1>
<?php /**PATH C:\xampp\htdocs\blog\resources\views/welcome1.blade.php ENDPATH**/ ?>