<?php $__env->startSection('content'); ?>
    <div class="starter-template mano">
        <h1>Bootstrap starter template</h1>
        <p class="lead mano"></p>
    </div>

    <h1 class="mano">Pasirinkite aukščiau skilti kur norite patekti</h1>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blog\resources\views/welcome.blade.php ENDPATH**/ ?>