<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-10">
            <h1>Visi irasai</h1>
        </div>
        <div class="col-md-2">
            <a href="<?php echo e(route('posts.create')); ?>" class="btn btn-success btn-block">Sukurti nauja</a>
        </div>
        <hr>
        <div class="row">
            <div class="col-md-12">
                <h3>Įregistruoti automobiliai</h3>
                <table class="table">
                    <thead>
                        <th>#</th>
                        <th>Pavadinimas</th>
                        <th>Modelis</th>
                        <th>Marke</th>
                        <th>Data</th>
                        <th>Rida</th>
                        <th>Kuras</th>
                        <th>Vairo padetis</th>
                        <th>Pavaros</th>
                        <th>Vairo padetis</th>
                        <th>Sukurta:</th>
                        <th>Redaguota:</th>
                        <th></th>
                    </thead>

                    <tbody>
                        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th><?php echo e($post->id); ?></th>
                                <td><?php echo e($post->title); ?></td>
                                <td><?php echo e($post->body); ?></td>
                                <td><?php echo e($post->model); ?></td>
                                <td><?php echo e($post->date); ?></td>
                                <td><?php echo e($post->km); ?></td>
                                <td><?php echo e($post->fuel); ?></td>
                                <td><?php echo e($post->wheel); ?></td>
                                <td><?php echo e($post->transmission); ?></td>
                                <td><?php echo e($post->created_at); ?></td>
                                <td><?php echo e($post->updated_at); ?></td>
                                <td><a href="<?php echo e(route('posts.show', $post->id)); ?>" class="btn btn-success btn-sm">Perziureti</a><a href="<?php echo e(route('posts.edit', $post->id)); ?>" class="btn btn-primary btn-sm">Redaguoti</a><a href="<?php echo e(route('posts.destroy', $post->id)); ?>" class="btn btn-danger btn-sm">Istrinti</a></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>



        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blog\resources\views/posts/index.blade.php ENDPATH**/ ?>