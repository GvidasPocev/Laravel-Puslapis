<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PagesController extends Controller
{
    public function index()
    {
        return view('welcome');
    }

    public function about()
    {
        $a = 1215-154*151;
        $b = 50;
        $c= $a + $b;
        $vardas = 'Matas';
        return view('pages.about')->with('vardas', $vardas)->with('c', $c);
    }

    public function contacts()
    {
        return view('pages.contacts');
    }
}

