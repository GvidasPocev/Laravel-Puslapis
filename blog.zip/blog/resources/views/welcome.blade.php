@extends('main')
@section('content')
    <div class="starter-template mano">
        <h1>Bootstrap starter template</h1>
        <p class="lead mano"></p>
    </div>

    <h1 class="mano">Pasirinkite aukščiau skilti kur norite patekti</h1>
@endsection

