<!doctype html>
@extends('main')
@section('content')<br><br><br>
<html lang="en">
<head>
    <title>Title</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
          integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>
<body>

<div class="container">
    <div class="row">
        <div class="col-md-8 offset-2">
            <form action="{{ route('posts.update', $post->id) }}" method="post">
                {{ method_field('PATCH') }}
                <div class="form-group">
                    <label for="Title">Iveskite pavadinima</label>
                    <input type="text" class="form-control" name="title" value="{{ $post->title }}">
                    <label for="Title">Iveskite marke</label>
                    <textarea name="body" rows="1" class="form-control">{{ $post->body }}</textarea>
                    <label for="Title">Iveskite modelio pavadinima</label>
                    <textarea name="model" rows="1" class="form-control">{{ $post->model }}</textarea>
                    <label for="Title">Iveskite pagaminimo data</label>
                    <textarea name="date" rows="1" class="form-control">{{ $post->date }}</textarea>
                    <label for="Title">Iveskite rida</label>
                    <textarea name="km" rows="1" class="form-control">{{ $post->km }}</textarea>
                    <label for="Title">Iveskite kuro tipa</label>
                    <textarea name="fuel" rows="1" class="form-control">{{ $post->fuel }}</textarea>
                    <label for="Title">Iveskite vairo padeti</label>
                    <textarea name="wheel" rows="1" class="form-control">{{ $post->wheel }}</textarea>
                    <label for="Title">Iveskite pavaru svirties tipa</label>
                    <textarea name="transmission" rows="1" class="form-control">{{ $post->transmission }}</textarea>
                </div>
                <button class="btn btn-success">Issaugoti</button>
                @csrf
            </form>
        </div>
    </div>
</div>
