@extends('main')
@section('content')
    <div class="row">
        <div class="col-md-10">
            <h1>Visi irasai</h1>
        </div>
        <div class="col-md-2">
            <a href="{{ route('posts.create') }}" class="btn btn-success btn-block">Sukurti nauja</a>
        </div>
        <hr>
        <div class="row">
            <div class="col-md-12">
                <h3>Įregistruoti automobiliai</h3>
                <table class="table">
                    <thead>
                        <th>#</th>
                        <th>Pavadinimas</th>
                        <th>Modelis</th>
                        <th>Marke</th>
                        <th>Data</th>
                        <th>Rida</th>
                        <th>Kuras</th>
                        <th>Vairo padetis</th>
                        <th>Pavaros</th>
                        <th>Vairo padetis</th>
                        <th>Sukurta:</th>
                        <th>Redaguota:</th>
                        <th></th>
                    </thead>

                    <tbody>
                        @foreach($posts as $post)
                            <tr>
                                <th>{{ $post->id }}</th>
                                <td>{{ $post->title }}</td>
                                <td>{{ $post->body }}</td>
                                <td>{{ $post->model}}</td>
                                <td>{{ $post->date}}</td>
                                <td>{{ $post->km}}</td>
                                <td>{{ $post->fuel}}</td>
                                <td>{{ $post->wheel}}</td>
                                <td>{{ $post->transmission}}</td>
                                <td>{{ $post->created_at }}</td>
                                <td>{{ $post->updated_at }}</td>
                                <td><a href="{{ route('posts.show', $post->id) }}" class="btn btn-success btn-sm">Perziureti</a><a href="{{ route('posts.edit', $post->id) }}" class="btn btn-primary btn-sm">Redaguoti</a><a href="{{ route('posts.destroy', $post->id) }}" class="btn btn-danger btn-sm">Istrinti</a></td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>



        </div>
    </div>
@endsection

