<!doctype html>
<html lang="en">
<head>
    <title>Puslapis</title>
    @include('partials._head')
</head>
<body>

    @include('partials._nav')

<div class="container">

    @yield('content')

</div><!-- /.container -->


    @include('partials._scripts')
</body>
</html>
