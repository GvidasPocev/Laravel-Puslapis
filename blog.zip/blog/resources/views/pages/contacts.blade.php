@extends('main')
@section('content')
        <h1>Bootstrap starter template</h1>
        <p class="lead">Puslapis contacts</p>
@stop
